var con = require('../config/db');

module.exports = app => {

    app.get('/clientes/listar', (req, res) => {

        let clientes = [];

        con.query("SELECT * FROM clientes", (erro, resultado) => {

            if (erro){
                console.log("Ocorreu um erro: ", erro);
            }else{
                clientes = resultado;
            }

            res.render('clientes/listar', { clientes : clientes });
        });
    });

    app.post('/clientes/listar', (req, res) => {
        let clientes = [];
        let consulta = (req.body.cpf === '') ? "SELECT * FROM clientes" : `SELECT * FROM clientes WHERE cpf LIKE '%${req.body.cpf}%'`;

        con.query(consulta, (erro, resultado) => {

            if (erro){
                console.log("Ocorreu um erro: ", erro);
            }else{
                clientes = resultado;
            }

            res.render('clientes/listar', { clientes : clientes });
        });
    });

    app.get('/clientes/adicionar', (req, res) => {
        res.render('clientes/adicionar');
    });

    app.post('/clientes/adicionar', (req, res) => {

        let cliente = {
            nome: req.body.nome,
            cpf: req.body.cpf,
            sexo: req.body.sexo,
            data_nascimento: req.body.data_nascimento
        }

        con.query("INSERT INTO clientes set ?", cliente, (erro, resultado) => {
            if (erro){
                console.log("Ocorreu um erro: ", erro);
            }else{
                console.log("Registro inserido com sucesso!");
            }
        });

        res.redirect('/clientes/listar');
    });

    app.get('/clientes/excluir/:id', (req, res) => {

        con.query("DELETE FROM clientes WHERE id=?", req.params.id, (erro, resultado) => {
            if (erro){
                console.log("Ocorreu um erro: ", erro);
            }else{
                console.log("O registro foi removido com sucesso!");
            }
        });

        res.redirect('/clientes/listar');
    });

    app.get('/clientes/editar/:id', (req, res) => {

        let cliente = {};

        con.query("SELECT * FROM clientes WHERE id = ?", req.params.id, (erro, resultado) => {
            if (erro){
                console.log("Ocorreu um erro: ", erro);
            }else{
                cliente = resultado[0];
            }

            res.render('clientes/editar', { cliente : cliente });
        });
    });

    app.post('/clientes/editar', (req, res) => {

        let id = req.body.id;
        let nome = req.body.nome;
        let cpf = req.body.cpf;
        let sexo = req.body.sexo;
        let data_nascimento = req.body.data_nascimento;

        con.query("UPDATE clientes SET nome=?, cpf=?, sexo=?, data_nascimento=? WHERE id=?", [nome, cpf, sexo, data_nascimento, id], (erro, resposta) => {
            if (erro){
                console.log("Ocorreu um erro: ", erro);
            }else{
                console.log("Registro foi atualizado com sucesso");
            }
        });

        res.redirect('/clientes/listar');
    });

}