const express = require('express');
const consign = require('consign');
   
module.exports = () => {
    const app = express();
    
    app.use(express.urlencoded({ extended : false }));
    app.set('view engine', 'ejs');       

    consign()
        .include('controllers')
        .into(app);

    return app;
}