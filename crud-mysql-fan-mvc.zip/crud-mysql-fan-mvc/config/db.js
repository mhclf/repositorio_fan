const mysql = require('mysql')

const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'crud_node'
});

con.connect(function(erro) {
    if (erro){
        console.log("Erro de conexão!");
    }else{
        console.log("Conexão efetuada com sucesso!");
    }

});

module.exports = con;