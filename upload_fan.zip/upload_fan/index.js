const express = require('express');
const fileUpload = require('express-fileupload');

var app = express();

app.use(express.urlencoded({ extended : false }));
app.set('view engine', 'ejs');
app.use(fileUpload());

app.listen(3000, () => {
    console.log('Servidor rodando...');
});

app.get('/', (req, res) => {
    res.render('form-upload');
});

app.post('/upload-arquivo', (req, res) => {

    let arquivo = req.files.arquivo;
    console.log(arquivo);

    arquivo.mv('./uploads/teste.pdf', (erro) => {

        if (erro){
            console.log('Ocorreu um erro: ', erro);
        }else{
            res.send('Arquivo carregado!');
        }

    });

});