const express = require('express');

const app = express();

app.use(express.urlencoded({ extended : false }));
app.set('view engine', 'ejs');
var con = require('./config/db');

app.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
});

app.get('/listar', (req, res) => {

    let alunos = [];

    con.query("SELECT * FROM alunos", function(erro, resultado) {

        if (erro){
            console.log("Ocorreu um erro: ", erro);
        }else{
            alunos = resultado;
        }

        res.render('listar', { alunos : alunos });
    });
});

app.post('/listar', (req, res) => {    
    let alunos = [];
    let consulta = (req.body.matricula === '') ? "SELECT * FROM alunos" : `SELECT * FROM alunos WHERE matricula like '%${req.body.matricula}%'`;

    con.query(consulta, function(erro, resultado) {

        if (erro){
            console.log("Ocorreu um erro: ", erro);
        }else{
            alunos = resultado;
        }

        res.render('listar', { alunos : alunos });
    });
});

app.get('/adicionar', (req, res) => {
    res.render('adicionar');
});

app.post('/adicionar', (req, res) => {

    let aluno = {
        nome: req.body.nome,
        idade: req.body.idade,
        matricula: req.body.matricula
    }

    con.query("INSERT INTO alunos set ?", aluno, function(erro, resultado) {
        if (erro){
            console.log("Ocorreu um erro: ", erro);
        }else{
            console.log("Registro inserido com sucesso!!!");
        }        
    });

    res.redirect('/listar');
});

app.get('/excluir/:id', (req, res) => {
    let id = req.params.id;

    con.query("DELETE FROM alunos WHERE id = ?", id, function(erro, resultado) {
        if (erro){
            console.log("Ocorreu um erro: ", erro);
        }else{
            console.log("Registro foi removido com sucesso!");
        }
    });

    res.redirect('/listar');
});

app.get('/editar/:id', (req, res) => {

    let id = req.params.id;
    let aluno = {};

    con.query("SELECT * FROM alunos WHERE id = ?", id, function(erro, resultado) {
        if (erro){
            console.log("Ocorreu um erro: ", erro);
        }else{
            aluno = resultado[0];
        }

        res.render('editar', { aluno : aluno});
    });    
});

app.post('/editar', (req, res) => {

    let id = req.body.id;
    let nome = req.body.nome;
    let idade = req.body.idade;
    let matricula =  req.body.matricula;

    con.query("UPDATE alunos SET nome=?, idade=?, matricula=? WHERE id=?", [nome, idade, matricula, id], function(erro, resultado) {
        if (erro){
            console.log("Ocorreu um erro: ", erro);
        }else{
            console.log("Registro alterado com sucesso!");
        }
    });

    res.redirect("/listar");
});