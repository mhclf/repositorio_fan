console.log("---------Expressões Aritméticas---------")

let x = 10;
let y = 3;

//let soma = x + y;

console.log("A soma é " + (x + y));
console.log("A subtração é " + (x - y));
console.log("A multiplicação é " + (x * y));
console.log("A divisão é " + (x / y));
console.log("O módulo (resto do divisão) é " + (x % y));
console.log("A potência é " + (x ** y));

console.log("O resultado da expressão é " + (((x + y) * 2) / 3) + (y * 3));