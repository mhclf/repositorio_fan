console.log("-------------Objetos-----------------");

let professor = new Object();

professor.nome = "Marcos";
professor.especialidade = "ES";
professor.matricula = 123;

console.log(professor);
console.log(typeof(professor));