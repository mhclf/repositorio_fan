console.log("---------Estrutura if (operação ternária)----------");

let x = 10;

let y = (x == 10) ? 2 : 5;

//Equivalente a linha 5
// if (x == 10){
//     y = 2;
// }else{
//     y = 5;
// }