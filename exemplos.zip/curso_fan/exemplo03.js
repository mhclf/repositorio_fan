console.log("----------Expressões de Comparação-------");

let x = 10;
let y = 2;
let z = "10";

console.log("x é maior que y? " + (x > y));
console.log("x é maior ou igual a y? " + (x >= y));
console.log("x é menor que y? " + (x < y));
console.log("x é menor ou igual a y? " + (x <= y));
console.log("x é igual a z (comparação entre valores)? " + (x == z));
console.log("x é igual a z (comparação entre valores e tipo de dado)? " + (x === z));
console.log("x é diferente de z (comparação entre valores)? " + (x != z));
console.log("x é diferente de z (comparação entre valores e tipo de dado)? " + (x !== z));