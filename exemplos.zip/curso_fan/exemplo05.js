console.log("--------- Interpolação entre Strings--------");

let nome = "Marcos";
let idade = 36;

console.log("Meu nome é " + nome + " e tenho " + idade + " anos");
console.log(`Meu nome é ${nome} e tenho ${idade} anos`);