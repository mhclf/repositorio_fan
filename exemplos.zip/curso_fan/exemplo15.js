console.log("------------Vetores (Array)--------------");

let colecao = [ 'Marcos', 'José', 'Maria' ];

console.log(colecao);

console.log(colecao[0]);
console.log(colecao[1]);
console.log(colecao[2]);

console.log(colecao.length);

colecao[0] = 'Marta';

console.log(colecao[0]);