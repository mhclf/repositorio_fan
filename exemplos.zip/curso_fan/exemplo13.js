console.log("----------Estrutura de Repetição (for)-----------");

for(let i = 0; i <= 10; i++){
    console.log(i);
}

console.log("----------------------");

for(let i = 10; i >= 0; i--){
    console.log(i);
}