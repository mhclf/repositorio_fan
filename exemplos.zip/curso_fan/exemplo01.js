console.log("--------Variáveis-----------")

let nome = "Marcos";
const idade = 36;

//A variável é uma constante, o que significa que não pode ser alterada
//idade = 33;

nome = "José"

console.log(nome);
console.log(typeof(nome));
console.log(typeof(idade));