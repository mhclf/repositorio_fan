console.log("------------ Funções (Anônimas)----------");

let imprimir = function(x){
    for(let i  = 0; i < x; i++){
        console.log(i);
    }
}

imprimir(10);