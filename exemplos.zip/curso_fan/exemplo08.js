console.log("-------------Estrutura if--------------");

let x = 10;

if (x == 10){
    console.log("X é igual a 10");
}else if (x > 10){
    console.log("X é maior que 10");
}else{
    console.log("X é menor que 10");
}