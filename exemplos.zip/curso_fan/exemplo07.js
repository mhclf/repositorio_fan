console.log("------------Estrutura if-------------");

let x = 11;

if (x == 10){
    console.log("X é igual a 10");
}else{
    console.log("X é diferente de 10");
}