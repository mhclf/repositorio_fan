console.log("------------ Funções (Arrow)----------");

let imprimir = (x) => {
    for(let i  = 0; i < x; i++){
        console.log(i);
    }
}

imprimir(10);