console.log("------------Estrutura if-------------");

let x = 10;

if (x == 10){
    console.log("X é igual a 10");
}