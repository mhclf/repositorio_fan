console.log("---------------------Objetos------------------");

let aluno = {};

aluno.nome = "Marcos";
aluno.idade = 36;
aluno.sexo = "Masculino";

console.log(aluno);
console.log(aluno.nome);
console.log(aluno.idade);
console.log(aluno.sexo);
console.log(typeof(aluno));