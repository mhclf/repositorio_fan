console.log("----------Estruturas de Repetição (while)----------");

//Equivalente a estrutura while
// console.log("1");
// console.log("2");
// console.log("3");
// console.log("4");
// console.log("5");
// console.log("6");
// console.log("7");
// console.log("8");
// console.log("9");
// console.log("10");

console.log("--------------------------");

let i = 11;

while(i <= 10){
    console.log(i);
    i++; //i = i + 1
}