console.log("---------------Estrurturas de Repetição (do...while)---------");

let x = 11;

do{
    console.log(x);
    x++; //x = x + 1
}while(x <= 10);