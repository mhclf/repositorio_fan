console.log("------------Expressões Lógicas-----------");

let x = true;
let y = false;

console.log("Negação de X -> " + !x);
console.log("Negação de Y -> " + !y);
console.log("X E Y -> " + (x && y));
console.log("X OU Y -> " + (x || y));