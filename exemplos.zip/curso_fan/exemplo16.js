console.log("-----------Vetores + Estruturas de Repetição---------");

let colecao = [ 'Marcos', 'Marta', 'Maria' ];

console.log(colecao[0]);
console.log(colecao[1]);
console.log(colecao[2]);

console.log("------------------");

for(let i = 0; i < colecao.length; i++){
    console.log(colecao[i]);
}