var express = require('express');
var cookieParser = require('cookie-parser');
var session = require('express-session');
const MySQLStore = require('express-mysql-session')(session);

var app = express();

app.use(cookieParser());

app.use(express.urlencoded({ extended : false }));
app.set('view engine', 'ejs');

var con = require('./config/db');

var sessionStore = new MySQLStore({}, con);

app.use(
    session({
        secret: 'Isso é secreto!! (OBS: usar uma combinacao enorme de caracteres)',
        resave: false,
        saveUninitialized: false,
        store: sessionStore
    })
);

app.listen(3000, ()=>{
    console.log("Servidor rodando na porta 3000");
});

app.get('/', (req, res) => {

    if (req.session.qtde_visualizacoes){
        req.session.qtde_visualizacoes++;
        res.send("Quantidade de visitas a rota: " + req.session.qtde_visualizacoes);
    }else{
        req.session.qtde_visualizacoes = 1;
        res.send("Bem-vindo(a)! Você está acessando essa rota pela primeira vez!");
    }
});

app.get('/principal', (req, res) => {    
    if (req.session.logado){
        res.render('principal');
    }else{
        res.redirect('/login');   
    }    
});

app.get('/cadastrar_usuario', (req, res) => {
    res.render('cadastrar_usuario');
});

app.post('/cadastrar_usuario', (req, res) => {

    con.query("INSERT INTO usuarios(login, senha) VALUES (?, md5(?))", [req.body.login, req.body.senha], function(erro, resultado) {
        if (erro){
            console.log("Ocorreu um erro: ", erro);
        }else{
            console.log("Registro inserido com sucesso!!!");
        }
    });

    res.redirect('/login');
});

app.get('/login', (req, res) => {
    if (req.session.logado){
        res.redirect('/principal');
    }else{
        res.render('login');
    }
});

app.post('/login', (req, res) => {

    con.query("SELECT * FROM usuarios WHERE login = ? and senha = md5(?)", [req.body.login, req.body.senha], function(erro, resultado) {
        if (erro){
            console.log("Ocorreu um erro: ", erro);
        }else{
            if (resultado.length == 1){
                req.session.logado = true;
                res.redirect('/principal');
            }else{
                res.redirect('/login');
            }            
        }
    });
});

app.get('/logout', (req, res) => {
    req.session.destroy();
    res.send('vc saiu do sistema!');
});