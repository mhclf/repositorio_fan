var express = require('express');
var cookieParser = require('cookie-parser');
var session = require('express-session');
const MySQLStore = require('express-mysql-session')(session);

var app = express();

app.use(cookieParser());

var con = require('./config/db');

var sessionStore = new MySQLStore({}, con);

app.use(
    session({
        secret: 'Isso é secreto!! (OBS: usar uma combinacao enorme de caracteres)',
        resave: false,
        saveUninitialized: false,
        store: sessionStore
    })
);

app.listen(3000, ()=>{
    console.log("Servidor rodando na porta 3000");
});

app.get('/', (req, res) => {

    if (req.session.qtde_visualizacoes){
        req.session.qtde_visualizacoes++;
        res.send("Quantidade de visitas a rota: " + req.session.qtde_visualizacoes);
    }else{
        req.session.qtde_visualizacoes = 1;
        res.send("Bem-vindo(a)! Você está acessando essa rota pela primeira vez!");
    }
});