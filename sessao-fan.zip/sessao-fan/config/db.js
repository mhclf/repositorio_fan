const mysql = require('mysql');

const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'crud_node'
});

con.connect((erro) => {
    if (erro){
        console.log('Ocorreu um erro: ', erro);
    }else{
        console.log('Conexão efetuada com sucesso!');
    }
});

module.exports = con;