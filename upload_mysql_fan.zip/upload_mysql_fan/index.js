const express = require('express');
const fileUpload = require('express-fileupload');

var app = express();

app.use(express.urlencoded({ extended : false }));
app.set('view engine', 'ejs');
app.use(fileUpload());

app.use('/arquivos', express.static('uploads'));

var con = require('./config/db');

app.listen(3000, () => {
    console.log('Servidor rodando...');
});

app.get('/', (req, res) => {

    let produtos = [];

    con.query("SELECT * FROM produtos", function(erro, resultado) {

        if (erro){
            console.log("Ocorreu um erro: ", erro);
        }else{
            produtos = resultado;
        }

        res.render('listar', { produtos : produtos });
    });
});

app.get('/adicionar', (req, res) => {
    res.render('adicionar');
});

app.post('/adicionar', (req, res) => {

    let arquivo = req.files.imagem;
    console.log(arquivo);

    arquivo.mv('./uploads/' + arquivo.name, (erro) => {

        if (erro){
            console.log('Ocorreu um erro: ', erro);
        }else{
            let produto = {
                nome: req.body.nome,
                imagem: arquivo.name
            }
        
            con.query("INSERT INTO produtos set ?", produto, function(erro, resultado) {
                if (erro){
                    console.log("Ocorreu um erro: ", erro);
                }else{
                    console.log("Registro inserido com sucesso!!!");
                }        
            });
        }
    });

    res.redirect('/');
});

app.get('/visualizar/:id', (req, res) => {
    let id = req.params.id;
    let produto = {};

    con.query("SELECT * FROM produtos WHERE id = ?", id, function(erro, resultado) {
        if (erro){
            console.log("Ocorreu um erro: ", erro);
        }else{
            produto = resultado[0];
        }

        res.render('visualizar', { produto : produto });
    });
});