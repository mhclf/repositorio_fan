const express = require('express');

const app = express();
app.use(express.urlencoded({ extended : false }));

var con = require('./config/db');

app.listen(3000, () => {
    console.log('servidor rodando na porta 3000');
});

//Retornando todos os registros
app.get('/api', (req, res) => {
    con.query("SELECT * FROM alunos", (erro, resultado) => {
        if (erro){
            res.json(erro);
        }else{
            res.json(resultado);
        }        
    });
});

//Retornando um registro específico
app.get('/api/:id', (req, res) => {
    con.query("SELECT * FROM alunos where id = ?", req.params.id, (erro, resultado) => {
        if (erro){
            res.json(erro);
        }else{
            res.json(resultado);
        }        
    });
});

//Adicionando registro
app.post('/api', (req, res) => {
    var aluno = req.body;

    con.query("INSERT INTO alunos SET ?", aluno, (erro, resultado) => {
        if (erro){
            res.json({ 'status' : 'erro' });            
        }else{
            res.json({ 'status' : 'inclusão realizada com sucesso!'});
        }
    });
});

//Excluindo um registro
app.delete('/api/:id', (req, res) => {

    con.query("DELETE FROM alunos WHERE id=?", req.params.id, (erro, resultado) => {
        if (erro){
            res.json(erro);
        }else{
            res.json(resultado);
        }
    });
});

//Atualizando um registro
app.put('/api/:id', (req, res) => {

    var aluno = req.body;

    con.query("UPDATE alunos SET nome=?, idade=?, matricula=? WHERE id=?", 
        [aluno.nome, aluno.idade, aluno.matricula, req.params.id], (erro, resultado) => {
        if (erro){
            res.json(erro);
        }else{
            res.json(resultado);
        }
    });
});