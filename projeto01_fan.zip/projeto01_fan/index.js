const express = require('express'); //primeiro passo, inclusão da biblioteca no projeto

const app = express(); //segundo passo, criação do objeto

app.use(express.urlencoded({ extended : false }));
app.set('view engine', 'ejs');

//terceiro passo, utilização de métodos do objeto criado
app.listen(3000, () => {
    console.log("Servidor rodando na porta 3000!");
});

//HTTP - GET
app.get('/', (req, res) => {    
    res.send("Olá Mundo!!!");
});

app.get('/outra_rota', (req, res) =>{
    res.send("<h1>Você está acessando outra rota!</h1>");
});

app.get('/tabuada', (req, res) => {
    // let numero = 9;
    let numero = (req.query.numero === undefined) ? 1 : req.query.numero;
    let resposta = '';

    for(let i = 1; i <= 10; i++){
        resposta += numero + ' * ' + i + ' = ' + (numero * i) + '<br/>';
    }

    res.send(resposta);
});

app.get('/tabuada/:numero', (req, res) => {

    let numero = req.params.numero;

    let resposta = '';

    for(let i = 1; i <= 10; i++){
        resposta += numero + ' * ' + i + ' = ' + (numero * i) + '<br/>';
    }

    res.send(resposta);

});

app.post('/ola', (req, res) => {
    let nome = (req.query.nome === undefined) ? '' : req.query.nome;
    let idade = (req.query.idade === undefined) ? '' : req.query.idade;

    res.send('Olá, ' + nome + ', você tem ' + idade + ' anos.');
});

app.get('/ola/:nome/:idade', (req, res) => {
    res.send('Olá, ' + req.params.nome + ', você tem ' + req.params.idade + ' anos.');
});

app.get('/teste_ejs', (req, res) => {
    res.render('teste');
});

app.get('/ola_com_view', (req, res) =>{
    let x = 'Marcos';

    res.render('ola', { nome : x });
});

app.get('/pares_solucao01', (req, res) => {

    let x = 1;
    let y = 10;
    let resposta = '';

    for(let i = x; i < y; i++){
        if (i % 2 == 0)
            resposta += i + ',';
    }

    res.render('pares01', { x : x, y : y, pares : resposta });
});

app.get('/pares_solucao02', (req, res) => {
    let x = 1;
    let y = 10;

    res.render('pares02', { x : x, y : y });
});

app.get('/formulario', (req, res) => {
    res.render('formulario');
});

app.post('/salvar', (req, res) => {
    let nome = req.body.nome;
    let idade = req.body.idade;

    res.render('resultado', { msg : `Olá ${nome}! Você tem ${idade} anos e seus dados foram recebidos!`});
});